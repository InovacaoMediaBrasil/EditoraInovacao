Resolution Of Devices :

1.iMac                     (1920 x 1080)
2.Macbook Air              (1440 x  900)
3.iPhone 5S Portrait - 3D  (640  x 1136)
4.iPhone 5C Portrait - 3D  (640  x 1136)
5.iPad Air  Portrait -     (2048 x 1536)

Get the full version of this pack Here :

http://crtv.mk/aTgw

-----------------------------------------------------

More Useful Products

http://crtv.mk/dTKX
http://crtv.mk/qTU2


Thanx